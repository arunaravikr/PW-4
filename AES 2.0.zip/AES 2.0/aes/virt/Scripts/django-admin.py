#!C:\Users\Aruna Ravi\Desktop\AES 2.0\aes\virt\Scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
